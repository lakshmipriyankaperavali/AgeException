package com.Exception;

import java.util.ArrayList;
import java.util.Collections;

public class SortList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> s1=new ArrayList();
		s1.add(10);
		s1.add(7);
		s1.add(20);
		s1.add(4);
		s1.add(5);
		Collections.sort(s1);
		System.out.println(s1);
		
	}

}
