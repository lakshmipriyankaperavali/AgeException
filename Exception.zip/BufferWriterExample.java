package com.Exception;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferWriterExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileWriter writer=new FileWriter("D:myfile1.txt",true);
			BufferedWriter br=new BufferedWriter(writer);
			br.write("Welcome World");
			br.write("\r\n");
			br.write("Hi there?!");
			br.close();
		}catch(IOException e){
			e.printStackTrace();
		}

	}

}
