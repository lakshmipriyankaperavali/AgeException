package com.Exception;

import java.io.FileWriter;
import java.io.IOException;

public class TextFileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileWriter writer=new FileWriter("D:myfile1.txt",true);
			writer.write("Hello World");
			writer.write("\r\n");
			writer.write("Good Bye!");
			writer.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
