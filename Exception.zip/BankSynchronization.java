package com.Exception;

class DaemonThread{
	int amount=0;
	int flag=0;
	public synchronized int withdraw(int amount){
		System.out.println(Thread.currentThread().getName()+"is going to withdraw");
		if(flag==0){
			try{
				System.out.println("Wait...as there is no sufficient amount in your account");
				wait();
				}
			catch(Exception e){
			}
			}
				this.amount-=amount;
		System.out.println("withdraw amount is"+amount);
		System.out.println("Withdraw completed successful");
		return amount;
	}
	public synchronized void deposit(int amount){
		System.out.println(Thread.currentThread().getName()+"is going to deposit");
		this.amount+=amount;
		System.out.println("deposited amount is"+amount);
		notifyAll();
		flag=1;
	}
}
	public class BankSynchronization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final DaemonThread dt=new DaemonThread();
		Thread t1=new Thread(){
			public void run(){
				dt.withdraw(2000);
				System.out.println("after withdrawal amount is"+dt.amount);
			}
		};
		Thread t2=new Thread(){
			public void run(){
				dt.deposit(5000);
				dt.withdraw(1000);
				System.out.println(" after deposit amount is"+dt.amount);
			}
		};
		t1.start();
		t1.setName("first thread");
		t2.start();
		t2.setName("second thread");
		
		
	}

}
