package com.Exception;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestReader {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try{
			FileReader fr=new FileReader("D:myfile1.txt");
			int c;
			while((c=fr.read())!=-1){
				System.out.println(c);
			}
			fr.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}

	}

}
