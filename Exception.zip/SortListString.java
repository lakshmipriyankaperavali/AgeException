package com.Exception;

import java.util.ArrayList;
import java.util.Collections;

public class SortListString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> s1=new ArrayList();
		s1.add("Rahul");
		s1.add("Ameena");
		s1.add("Saini");
		s1.add("reets");
		s1.add("Zeenath");
		Collections.sort(s1);
		System.out.println(s1);
		

	}

}
