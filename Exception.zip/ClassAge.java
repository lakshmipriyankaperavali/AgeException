package com.Exception;

public class ClassAge extends RuntimeException {
	String message;
	public ClassAge(String message) {
		super();
		this.message = message;
	}
	public String getMessage(){
		return message;
	}
}
