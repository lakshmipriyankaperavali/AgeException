package com.Exception;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparableExample {

	public static void main(String[] args) {
		ArrayList<Sttudent> al=new ArrayList<Sttudent>();    
		 al.add(new Sttudent(101,"Vijay",23));    
		 al.add(new Sttudent(106,"Ajay",27));    
		 al.add(new Sttudent(105,null,21));    
		 Comparator<Sttudent> cm1=Comparator.comparing(Sttudent::getName,Comparator.nullsFirst(String::compareTo));  
		  Collections.sort(al,cm1);  
		  System.out.println("Considers null to be less than non-null");  
		  for(Sttudent st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		     }  
		  Comparator<Sttudent> cm2=Comparator.comparing(Sttudent::getName,Comparator.nullsLast(String::compareTo));  
		  Collections.sort(al,cm2);  
		  System.out.println("Considers null to be greater than non-null");  
		  for(Sttudent st: al){  
		     System.out.println(st.rollno+" "+st.name+" "+st.age);  
		  }
	}
}
		



