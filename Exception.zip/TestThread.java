package com.Exception;

public class TestThread implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In Run Method");
		System.out.println();
	}
	public static void main(String args[]){
		TestThread t=new TestThread();
		Thread tt=new Thread(t);
		tt.start();
		tt.setName("My First Thread");
	}
}
