package com.Exception;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> li=new ArrayList<String>();
		li.add("Amul");
		li.add(null);
		li.add(null);
		li.add("Rita");
		System.out.println(li);
		List list2=new ArrayList();
		list2.addAll(li);
		System.out.println("Before adding data at specified position:"+list2);
		
		
		
	}

}
