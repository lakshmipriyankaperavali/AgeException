package com.Exception;

import java.util.Scanner;

public class Age1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age :");
		age=sc.nextInt();
		if(age<18){
		 throw new ClassAge("Invalid user");
		}

	}

}
