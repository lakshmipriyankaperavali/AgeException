package com.Exception;

public class MultiTasking extends Thread{
	public void run(){
			System.out.println("In RunMethod1");
		}
	    
}
class MultiTasking1 extends Thread{
	public void run(){
		System.out.println("In RunMethod2");
	}
	public static void main(String args[]){
		MultiTasking t=new MultiTasking();
		MultiTasking1 t1=new MultiTasking1();
		t.start();
		t1.start();
		t.run();
		t1.run();
	}
	
}